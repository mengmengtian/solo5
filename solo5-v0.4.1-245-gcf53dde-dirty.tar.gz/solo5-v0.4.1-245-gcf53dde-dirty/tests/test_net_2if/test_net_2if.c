#define TWO_INTERFACES
#include "../test_net/test_net.c"
