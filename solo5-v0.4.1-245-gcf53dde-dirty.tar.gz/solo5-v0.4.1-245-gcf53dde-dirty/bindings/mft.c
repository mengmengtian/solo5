#include "bindings.h"

#include "../tenders/common/mft.c"
